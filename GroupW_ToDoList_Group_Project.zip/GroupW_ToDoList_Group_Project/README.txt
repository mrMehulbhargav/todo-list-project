
To-Do List Group Project

Project Overview:
This is a dynamic To-Do List Application project created using HTML, CSS, and JavaScript. The application allows users to add, complete, and delete tasks interactively. This README provides instructions on running the project and navigating the codebase.

Directory Guide:
- Task1_SettingUpProject: Basic project setup including HTML structure.
- Task2_DOM_Manipulation_and_Styling: DOM manipulation and styling code.
- Task3_Error_Handling: JavaScript error handling examples.
- Task4_User_Interaction: Features for user interactions (marking complete, clearing tasks).
- Task5_Final_Touches: Final optimizations and comments.

Instructions to Run:
1. Open the index.html file in a web browser.
2. Ensure all JavaScript and CSS files are in the correct folders as per the structure.
3. Follow comments in the code for each task's specific features.

