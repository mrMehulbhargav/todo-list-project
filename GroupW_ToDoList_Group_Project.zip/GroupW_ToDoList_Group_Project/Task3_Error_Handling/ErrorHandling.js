
try {
    addtask();
} catch (error) {
    console.error("An error occurred while adding the task:", error);
}
