
console.log("Todo List Application initialized.");
