
document.querySelector("form").addEventListener("submit", function(event) {
    event.preventDefault();
    addtask();
});
