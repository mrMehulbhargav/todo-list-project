
function addtask() {
    const taskInput = document.getElementById('AddTask');
    const taskList = document.getElementById('tasklist');

    const taskText = taskInput.value.trim();
    if (taskText.length === 0) return;

    const listItem = document.createElement('li');
    listItem.className = "list-group-item d-flex justify-content-between align-items-center text-white";
    listItem.style.backgroundColor = "#2A2649";
    listItem.style.border = "1px solid #2A2649";
    listItem.style.marginTop = "10px";

    const taskContent = document.createElement('span');
    taskContent.innerText = taskText;
    listItem.appendChild(taskContent);

    taskList.appendChild(listItem);
    taskInput.value = "";
}
